
      UPDATE orders
      SET proposed_price = {{params.proposed_price}}::numeric,
          status = 'pending_customer_approval'
      WHERE id = {{params.id}}::bigint;
    