
      UPDATE orders
      SET proposed_price = :param0::numeric,
          status = 'pending_customer_approval'
      WHERE id = :param1::bigint;
    