
      UPDATE orders
      SET status = {{params.status}}
      WHERE id = {{params.id}}::bigint;
    