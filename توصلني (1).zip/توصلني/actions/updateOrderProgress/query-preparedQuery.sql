
      UPDATE orders
      SET status = :param0
      WHERE id = :param1::bigint;
    