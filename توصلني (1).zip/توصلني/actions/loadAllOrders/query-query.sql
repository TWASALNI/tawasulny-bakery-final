
      SELECT
        o.*,
        d.full_name AS driver_name,
        d.phone AS driver_phone,
        (SELECT COUNT(*) FROM order_applications oa WHERE oa.order_id = o.id) AS applicants_count
      FROM orders o
      LEFT JOIN drivers d ON o.driver_id = d.id
      WHERE
        COALESCE({{params.status}}, 'all') = 'all'
        OR o.status = {{params.status}}
      ORDER BY o.created_at DESC;
    