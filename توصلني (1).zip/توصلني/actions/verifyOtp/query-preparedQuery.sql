
      UPDATE verification_codes
      SET used = TRUE
      WHERE phone = :param0
        AND code = :param1
        AND used = FALSE
        AND expires_at > NOW()
      RETURNING id, phone, code;
    