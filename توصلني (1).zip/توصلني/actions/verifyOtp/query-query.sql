
      UPDATE verification_codes
      SET used = TRUE
      WHERE phone = {{params.phone}}
        AND code = {{params.code}}
        AND used = FALSE
        AND expires_at > NOW()
      RETURNING id, phone, code;
    