
      UPDATE orders
      SET status = 'available_to_drivers'
      WHERE id = :param0::bigint;
    