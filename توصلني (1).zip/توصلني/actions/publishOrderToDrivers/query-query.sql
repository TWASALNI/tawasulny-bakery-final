
      UPDATE orders
      SET status = 'available_to_drivers'
      WHERE id = {{params.id}}::bigint;
    