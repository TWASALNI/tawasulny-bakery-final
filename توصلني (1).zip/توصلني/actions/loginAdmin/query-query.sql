
      UPDATE users
      SET session_token = md5(random()::text || clock_timestamp()::text),
          session_expires_at = NOW() + INTERVAL '8 hours'
      WHERE is_admin = TRUE
        AND password = md5({{params.password}})
      RETURNING id, full_name, phone, role, session_token;
    