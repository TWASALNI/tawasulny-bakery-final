
      SELECT
        oa.id, oa.order_id, oa.applied_at, oa.status,
        d.id AS driver_id, d.full_name AS driver_name,
        d.phone AS driver_phone, d.is_available,
        COALESCE(ROUND(AVG(r.rating)::numeric, 1), 0) AS avg_rating,
        COUNT(DISTINCT r.id) AS total_ratings,
        COUNT(DISTINCT o.id) AS total_orders
      FROM order_applications oa
      JOIN drivers d ON d.id = oa.driver_id
      LEFT JOIN ratings r ON r.driver_id = d.id
      LEFT JOIN orders o ON o.driver_id = d.id AND o.status = 'in_progress'
      WHERE oa.order_id = :param0::bigint
      GROUP BY oa.id, oa.order_id, oa.applied_at, oa.status, d.id, d.full_name, d.phone, d.is_available
      ORDER BY avg_rating DESC, oa.applied_at ASC;
    