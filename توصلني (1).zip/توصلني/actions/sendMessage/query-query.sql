
      INSERT INTO messages (order_id, sender_role, sender_name, driver_id, customer_phone, message)
      VALUES (
        NULLIF({{params.order_id}}, '')::bigint,
        {{params.sender_role}},
        {{params.sender_name}},
        NULLIF({{params.driver_id}}, '')::bigint,
        NULLIF({{params.customer_phone}}, ''),
        {{params.message}}
      );
    