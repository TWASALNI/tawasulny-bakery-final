
      INSERT INTO messages (order_id, sender_role, sender_name, driver_id, customer_phone, message)
      VALUES (
        NULLIF(:param0, '')::bigint,
        :param1,
        :param2,
        NULLIF(:param3, '')::bigint,
        NULLIF(:param4, ''),
        :param5
      );
    