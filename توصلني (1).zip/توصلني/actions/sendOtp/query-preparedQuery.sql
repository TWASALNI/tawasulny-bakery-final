
      -- Invalidate any previous unused codes for this phone
      UPDATE verification_codes
      SET used = TRUE
      WHERE phone = :param0 AND used = FALSE;

      -- Insert a new 4-digit OTP code
      INSERT INTO verification_codes (phone, code, expires_at)
      VALUES (
        :param1,
        LPAD(FLOOR(RANDOM() * 10000)::int::text, 4, '0'),
        NOW() + INTERVAL '10 minutes'
      )
      RETURNING code, expires_at;
    