
      SELECT * FROM messages
      WHERE
        (:param0::bigint > 0 AND driver_id = :param1::bigint)
        OR
        (:param2 IS NOT NULL AND :param3 != '' AND customer_phone = :param4)
      ORDER BY created_at ASC;
    