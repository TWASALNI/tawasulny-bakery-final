
      SELECT * FROM messages
      WHERE
        ({{params.driver_id}}::bigint > 0 AND driver_id = {{params.driver_id}}::bigint)
        OR
        ({{params.customer_phone}} IS NOT NULL AND {{params.customer_phone}} != '' AND customer_phone = {{params.customer_phone}})
      ORDER BY created_at ASC;
    