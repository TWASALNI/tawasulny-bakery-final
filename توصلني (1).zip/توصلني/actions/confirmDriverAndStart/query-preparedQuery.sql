
      UPDATE orders
      SET driver_id = :param0::bigint,
          status = 'active_monthly',
          final_price = proposed_price,
          admin_commission = proposed_price * 0.10,
          payment_status = 'paid'
      WHERE id = :param1::bigint;
    