
      SELECT n.*, o.customer_name, o.city
      FROM notifications n
      LEFT JOIN orders o ON o.id = n.order_id
      WHERE
        n.target_role = {{params.role}}
        OR (n.target_role = 'driver' AND n.target_driver_id = {{params.driver_id}}::bigint)
      ORDER BY n.created_at DESC
      LIMIT 50;
    