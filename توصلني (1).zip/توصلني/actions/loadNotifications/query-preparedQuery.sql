
      SELECT n.*, o.customer_name, o.city
      FROM notifications n
      LEFT JOIN orders o ON o.id = n.order_id
      WHERE
        n.target_role = :param0
        OR (n.target_role = 'driver' AND n.target_driver_id = :param1::bigint)
      ORDER BY n.created_at DESC
      LIMIT 50;
    