
      SELECT id, full_name, phone, driver_status, is_banned, terms_accepted
      FROM drivers
      WHERE phone = :param0
        AND password = md5(:param1)
        AND driver_status = 'approved'
        AND (is_banned = FALSE OR is_banned IS NULL)
      LIMIT 1;
    