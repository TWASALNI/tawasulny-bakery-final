
      SELECT customer_name, customer_phone, customer_identifier
      FROM orders
      WHERE customer_identifier = :param0
         OR customer_phone = :param1
      LIMIT 1;
    