
      SELECT customer_name, customer_phone, customer_identifier
      FROM orders
      WHERE customer_identifier = {{params.phone}}
         OR customer_phone = {{params.phone}}
      LIMIT 1;
    