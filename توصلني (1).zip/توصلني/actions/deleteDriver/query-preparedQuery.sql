
      -- Detach driver from orders first to satisfy FK constraint
      UPDATE orders SET driver_id = NULL WHERE driver_id = :param0::bigint;
      -- Remove driver applications
      DELETE FROM order_applications WHERE driver_id = :param1::bigint;
      -- Remove driver messages
      DELETE FROM messages WHERE driver_id = :param2::bigint;
      -- Remove driver ratings
      DELETE FROM ratings WHERE driver_id = :param3::bigint;
      -- Remove driver notifications
      DELETE FROM notifications WHERE target_driver_id = :param4::bigint;
      -- Now delete the driver
      DELETE FROM drivers WHERE id = :param5::bigint;
    