
      INSERT INTO ratings (order_id, driver_id, customer_name, rating, comment)
      VALUES (
        {{params.order_id}}::bigint,
        {{params.driver_id}}::bigint,
        {{params.customer_name}},
        {{params.rating}}::int,
        {{params.comment}}
      );
    