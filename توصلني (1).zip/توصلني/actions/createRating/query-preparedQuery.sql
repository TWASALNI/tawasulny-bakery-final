
      INSERT INTO ratings (order_id, driver_id, customer_name, rating, comment)
      VALUES (
        :param0::bigint,
        :param1::bigint,
        :param2,
        :param3::int,
        :param4
      );
    