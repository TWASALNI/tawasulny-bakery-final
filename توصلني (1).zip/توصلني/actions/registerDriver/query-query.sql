
      INSERT INTO drivers (
        full_name, phone, city, vehicle_type, car_model, age, nationality,
        is_available, driver_status, terms_accepted,
        password, is_verified
      )
      VALUES (
        {{params.full_name}},
        {{params.phone}},
        {{params.city}},
        {{params.vehicle_type}},
        {{params.car_model}},
        {{params.age}}::int,
        {{params.nationality}},
        false,
        'pending_approval',
        {{params.terms_accepted}},
        md5({{params.password}}),
        false
      )
      RETURNING id;
    