
      INSERT INTO drivers (
        full_name, phone, city, vehicle_type, car_model, age, nationality,
        is_available, driver_status, terms_accepted,
        password, is_verified
      )
      VALUES (
        :param0,
        :param1,
        :param2,
        :param3,
        :param4,
        :param5::int,
        :param6,
        false,
        'pending_approval',
        :param7,
        md5(:param8),
        false
      )
      RETURNING id;
    