
      UPDATE notifications
      SET is_read = TRUE
      WHERE
        COALESCE(:param0, 0) = 0
        OR id = :param1::bigint;
    