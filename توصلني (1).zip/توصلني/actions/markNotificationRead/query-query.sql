
      UPDATE notifications
      SET is_read = TRUE
      WHERE
        COALESCE({{params.id}}, 0) = 0
        OR id = {{params.id}}::bigint;
    