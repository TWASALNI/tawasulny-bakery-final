
      UPDATE orders
      SET final_price = {{params.final_price}}::numeric,
          admin_commission = ({{params.final_price}}::numeric * 0.10)
      WHERE id = {{params.id}}::bigint;
    