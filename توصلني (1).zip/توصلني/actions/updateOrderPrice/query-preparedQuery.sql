
      UPDATE orders
      SET final_price = :param0::numeric,
          admin_commission = (:param1::numeric * 0.10)
      WHERE id = :param2::bigint;
    