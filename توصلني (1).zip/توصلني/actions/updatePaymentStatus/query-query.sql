
      UPDATE orders
      SET payment_status = {{params.payment_status}}
      WHERE id = {{params.id}}::bigint;
    