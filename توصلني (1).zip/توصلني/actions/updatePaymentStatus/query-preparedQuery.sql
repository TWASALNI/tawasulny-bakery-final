
      UPDATE orders
      SET payment_status = :param0
      WHERE id = :param1::bigint;
    