
      UPDATE supervisors
      SET full_name = {{params.full_name}},
          phone = {{params.phone}},
          permissions = {{params.permissions}},
          role = {{params.role}},
          is_active = {{params.is_active}}
      WHERE id = {{params.id}}::bigint
      RETURNING id;
    