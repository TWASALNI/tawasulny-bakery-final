
      UPDATE supervisors
      SET full_name = :param0,
          phone = :param1,
          permissions = :param2,
          role = :param3,
          is_active = :param4
      WHERE id = :param5::bigint
      RETURNING id;
    