
      SELECT
        o.id,
        o.city,
        o.neighborhood,
        o.final_price,
        o.admin_commission,
        o.status,
        o.commission_paid,
        o.commission_paid_at,
        o.created_at,
        (o.final_price - o.admin_commission) AS driver_net
      FROM orders o
      WHERE o.driver_id = {{params.driver_id}}::bigint
        AND o.status = 'completed'
      ORDER BY o.created_at DESC;
    