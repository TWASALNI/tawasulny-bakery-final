
      UPDATE drivers
      SET full_name = :param0,
          phone = :param1,
          city = :param2,
          nationality = :param3,
          vehicle_type = :param4,
          car_model = :param5,
          password = CASE
            WHEN :param6 = '' THEN password
            ELSE md5(:param7)
          END
      WHERE id = :param8::bigint
      RETURNING id;
    