
      UPDATE drivers
      SET full_name = {{params.full_name}},
          phone = {{params.phone}},
          city = {{params.city}},
          nationality = {{params.nationality}},
          vehicle_type = {{params.vehicle_type}},
          car_model = {{params.car_model}},
          password = CASE
            WHEN {{params.password}} = '' THEN password
            ELSE md5({{params.password}})
          END
      WHERE id = {{params.id}}::bigint
      RETURNING id;
    