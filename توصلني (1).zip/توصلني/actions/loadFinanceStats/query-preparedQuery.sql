
      SELECT
        d.id AS driver_id,
        d.full_name AS driver_name,
        d.phone AS driver_phone,
        COUNT(DISTINCT o.id) AS total_orders,
        COALESCE(SUM(CASE WHEN o.status = 'completed' THEN o.final_price ELSE 0 END), 0) AS total_revenue,
        COALESCE(SUM(CASE WHEN o.status = 'completed' THEN o.admin_commission ELSE 0 END), 0) AS total_commission,
        COALESCE(SUM(CASE WHEN o.status = 'completed' AND o.commission_paid = TRUE THEN o.admin_commission ELSE 0 END), 0) AS paid_commission,
        COALESCE(SUM(CASE WHEN o.status = 'completed' AND o.commission_paid = FALSE THEN o.admin_commission ELSE 0 END), 0) AS pending_commission,
        COALESCE(SUM(CASE WHEN o.status = 'completed' THEN o.final_price - o.admin_commission ELSE 0 END), 0) AS driver_earnings
      FROM drivers d
      LEFT JOIN orders o ON o.driver_id = d.id
      WHERE d.driver_status = 'approved'
      GROUP BY d.id, d.full_name, d.phone
      ORDER BY pending_commission DESC;
    