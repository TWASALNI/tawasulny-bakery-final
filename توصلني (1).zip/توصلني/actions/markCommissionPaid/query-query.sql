
      UPDATE orders
      SET commission_paid = TRUE,
          commission_paid_at = NOW()
      WHERE driver_id = {{params.driver_id}}::bigint
        AND status = 'completed'
        AND commission_paid = FALSE;
    