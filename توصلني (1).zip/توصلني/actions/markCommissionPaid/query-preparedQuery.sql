
      UPDATE orders
      SET commission_paid = TRUE,
          commission_paid_at = NOW()
      WHERE driver_id = :param0::bigint
        AND status = 'completed'
        AND commission_paid = FALSE;
    